"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const test = require("node:test");
const vm = require("node:vm");

const html = fs.readFileSync("index.html", "utf8");

function extractFunction(name) {
  const match = html.match(
    new RegExp(`^(?:async )?function ${name}\\([^\\n]*\\)\\{[\\s\\S]*?^\\}`, "m"),
  );
  assert.ok(match, `${name} must exist in index.html`);
  return match[0];
}

function makeContext({ mode = "signup", response = { data: { session: null }, error: null } } = {}) {
  const elements = {
    authModalTitle: { textContent: "Sign in" },
    authSubmitButton: { disabled: false },
    authModeButton: { hidden: false },
    authForgotPasswordButton: { hidden: false, disabled: false },
    authResendButton: { hidden: true, disabled: false },
    authModalMessage: { textContent: "" },
    authEmailField: { hidden: false },
    authPasswordLabel: { textContent: "Password" },
    authEmail: {
      value: "demo@example.test",
      disabled: false,
      required: true,
      checkValidity: () => true,
      reportValidity() {},
      focus() {},
    },
    authPassword: { value: "synthetic-password", focus() {} },
    authModal: { classList: { add() {}, remove() {} } },
  };
  const calls = {};
  const logs = [];
  const auth = {
    signUp: async (params) => {
      calls.signUp = params;
      return response;
    },
    signInWithPassword: async (params) => {
      calls.signInWithPassword = params;
      return response;
    },
    resend: async (params) => {
      calls.resend = params;
      return { error: null };
    },
    resetPasswordForEmail: async (email, options) => {
      calls.resetPasswordForEmail = { email, options };
      return { error: null };
    },
    updateUser: async (params) => {
      calls.updateUser = params;
      return { data: { user: { email: "demo@example.test" } }, error: null };
    },
  };
  const context = vm.createContext({
    authMode: mode,
    supabaseAuthClient: { auth },
    window: {
      location: {
        origin: "https://stockwise-test.example",
        hostname: "stockwise-test.replit.dev",
      },
    },
    document: { getElementById: (id) => elements[id] },
    renderAuthSession() {},
    console: { warn: (...args) => logs.push(args) },
    toast: (message) => {
      calls.toast = message;
    },
  });
  return { context, elements, calls, logs };
}

test("signup sends email confirmation back to the reachable app origin", async () => {
  const { context, calls, elements } = makeContext();
  vm.runInContext(extractFunction("submitAuth"), context);

  await context.submitAuth({ preventDefault() {} });

  assert.equal(calls.signUp.options.emailRedirectTo, "https://stockwise-test.example");
  assert.equal(elements.authResendButton.hidden, false);
  assert.match(elements.authModalMessage.textContent, /Check your email for the confirmation link/);
});

test("unconfirmed email error offers a resend action", async () => {
  const { context, elements } = makeContext({
    mode: "signin",
    response: { data: {}, error: { code: "email_not_confirmed" } },
  });
  vm.runInContext(extractFunction("submitAuth"), context);

  await context.submitAuth({ preventDefault() {} });

  assert.equal(elements.authResendButton.hidden, false);
  assert.match(elements.authModalMessage.textContent, /email is not confirmed/i);
});

test("invalid credentials are identified only for the explicit Supabase error code", async () => {
  const { context, elements } = makeContext({
    mode: "signin",
    response: { data: {}, error: { code: "invalid_credentials" } },
  });
  vm.runInContext(extractFunction("submitAuth"), context);

  await context.submitAuth({ preventDefault() {} });

  assert.match(elements.authModalMessage.textContent, /email or password is incorrect/i);
  assert.equal(elements.authResendButton.hidden, true);
});

test("resend uses Supabase signup resend and the current app origin", async () => {
  const { context, calls, elements } = makeContext();
  vm.runInContext(extractFunction("resendConfirmationEmail"), context);

  await context.resendConfirmationEmail();

  assert.equal(calls.resend.type, "signup");
  assert.equal(calls.resend.email, "demo@example.test");
  assert.equal(calls.resend.options.emailRedirectTo, "https://stockwise-test.example");
  assert.match(elements.authModalMessage.textContent, /confirmation email has been requested/i);
});

test("forgot password requests a reset link for the entered email and current origin", async () => {
  const { context, calls, elements } = makeContext({ mode: "signin" });
  vm.runInContext(extractFunction("requestPasswordReset"), context);

  await context.requestPasswordReset();

  assert.equal(calls.resetPasswordForEmail.email, "demo@example.test");
  assert.equal(calls.resetPasswordForEmail.options.redirectTo, "https://stockwise-test.example");
  assert.match(elements.authModalMessage.textContent, /password reset email has been requested/i);
});

test("forgot password asks for a valid email before making a request", async () => {
  const { context, calls, elements } = makeContext({ mode: "signin" });
  elements.authEmail.value = "";
  elements.authEmail.checkValidity = () => false;
  vm.runInContext(extractFunction("requestPasswordReset"), context);

  await context.requestPasswordReset();

  assert.equal(calls.resetPasswordForEmail, undefined);
  assert.match(elements.authModalMessage.textContent, /Enter your registered email address/i);
});

test("forgot password shows a clear error when Supabase rejects the request", async () => {
  const { context, elements } = makeContext({ mode: "signin" });
  context.supabaseAuthClient.auth.resetPasswordForEmail = async () => ({
    error: { code: "over_email_send_rate_limit", status: 429, name: "AuthApiError" },
  });
  vm.runInContext(extractFunction("logPasswordResetError"), context);
  vm.runInContext(extractFunction("passwordResetErrorMessage"), context);
  vm.runInContext(extractFunction("requestPasswordReset"), context);

  await context.requestPasswordReset();

  assert.match(elements.authModalMessage.textContent, /Too many reset emails/i);
});

test("reset error messages use recognized codes and keep unknown errors generic", () => {
  const { context } = makeContext();
  vm.runInContext(extractFunction("passwordResetErrorMessage"), context);

  assert.match(
    context.passwordResetErrorMessage({ code: "redirect_to_not_allowed" }),
    /redirect allowlist/i,
  );
  assert.match(
    context.passwordResetErrorMessage({ code: "over_email_send_rate_limit" }),
    /Wait a while/i,
  );
  assert.match(
    context.passwordResetErrorMessage({ code: "unknown_error" }),
    /Unable to request a password reset/i,
  );
});

test("development diagnostics keep safe error fields and omit message contents", () => {
  const { context, logs } = makeContext();
  vm.runInContext(extractFunction("logPasswordResetError"), context);

  context.logPasswordResetError({
    code: "redirect_to_not_allowed",
    name: "AuthApiError",
    status: 400,
    message: "user@example.test token=synthetic-test-token",
  });
  const output = JSON.stringify(logs);

  assert.match(output, /redirect_to_not_allowed/);
  assert.match(output, /AuthApiError/);
  assert.match(output, /400/);
  assert.doesNotMatch(output, /user@example\.test|synthetic-test-token/);

  context.window.location.hostname = "stockwise.replit.app";
  context.logPasswordResetError({ code: "forbidden" });
  assert.equal(logs.length, 1);
});

test("password recovery opens a new-password form and updates the password", async () => {
  const { context, calls, elements } = makeContext({ mode: "recovery" });
  vm.runInContext(extractFunction("updateAuthForm"), context);
  vm.runInContext(extractFunction("enterPasswordRecovery"), context);
  vm.runInContext(extractFunction("submitAuth"), context);

  context.enterPasswordRecovery();
  assert.equal(elements.authEmailField.hidden, true);
  assert.equal(elements.authEmail.disabled, true);
  assert.equal(elements.authPasswordLabel.textContent, "New password");
  elements.authPassword.value = "new-synthetic-password";
  await context.submitAuth({ preventDefault() {} });

  assert.equal(calls.updateUser.password, "new-synthetic-password");
  assert.equal(calls.toast, "Password updated successfully.");
});
