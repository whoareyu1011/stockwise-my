const { Pool } = require("pg");

async function main() {
  const connectionString = process.env.STOCKWISE_DATABASE_URL;

  if (!connectionString) {
    throw new Error("STOCKWISE_DATABASE_URL is missing");
  }

  const pool = new Pool({
    connectionString,
    connectionTimeoutMillis: 10000,
    max: 1,
    ssl: { rejectUnauthorized: false },
  });

  try {
    const result = await pool.query(`
      SELECT
        current_database() AS database_name,
        current_user AS current_role,
        NOW() AS server_time
    `);

    console.log("Database connection successful");
    console.log(result.rows[0]);
  } catch (error) {
    console.error("Database connection failed:", error.message);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
}

main();